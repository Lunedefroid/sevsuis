// var kaf_name = document.querySelectorAll('.kafedra_name');
// toUpperCase(kaf_name);
