<!DOCTYPE HTML>
<head>
  <title>Пример</title>
  <meta charset="utf-8">
   <link href="third/bootstrap/css/bootstrap.min.css" rel="stylesheet">
   <link href="css/test.css" rel="stylesheet">
</head>
<body>
    <script src="http://code.jquery.com/jquery-latest.js"></script>
    <script src="third/bootstrap/js/bootstrap.min.js"></script>
    <h1>
      <?php include('php/test.php') ?>
    </h1>
    <script src="js/test.js"></script>
    <div class="button">
      <button>Жми сюда</button>
    </div>
</body>
