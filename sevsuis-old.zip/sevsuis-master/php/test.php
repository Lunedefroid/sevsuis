<?php
  $first = "PHP";
  $second = "Работает";
  echo $first . " " . $second . "!";
?>
