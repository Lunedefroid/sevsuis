$(document).ready(function(){
    $("button").click(function(){
        alert("JS тоже!");
    });
});
