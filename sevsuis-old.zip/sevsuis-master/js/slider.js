$(document).on('ready', function(){
  $(".vertical-center").slick({
         dots: true,
         horizontal: true, //направление листания
         centerMode: false, //части соседних новостей
       });
});
